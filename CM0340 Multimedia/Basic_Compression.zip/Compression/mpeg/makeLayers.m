function c= makeLayers(c)
c=c;

