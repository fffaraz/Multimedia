load('handel')
[N M] = size(y);
figure(1)
spectrogram(fft(y,N),512,20,1024,Fs);
